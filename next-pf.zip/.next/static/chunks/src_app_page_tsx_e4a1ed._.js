(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_e4a1ed._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_e4a1ed._.js",
  "chunks": [
    "static/chunks/node_modules_6e7b99._.js",
    "static/chunks/src_4774f7._.js"
  ],
  "source": "dynamic"
});
